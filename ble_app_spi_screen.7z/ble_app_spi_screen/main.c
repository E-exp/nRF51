/**
 * Copyright (c) 2014 - 2017, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

/** @file
 *
 * @defgroup ble_sdk_uart_over_ble_main main.c
 * @{
 * @ingroup  ble_sdk_app_nus_eval
 * @brief    UART over BLE application main file.
 *
 * This file contains the source code for a sample application that uses the Nordic UART service.
 * This application uses the @ref srvlib_conn_params module.
 */
#include "ili9341.h"
#include "app_button.h"
#include "app_timer.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "ble_hci.h"
#include "nordic_common.h"
#include "nrf.h"
#include "nrf_assert.h"
#include "softdevice_handler.h"
#include <stdint.h>
#include <string.h>

#include "ble_bas.h"
#include "ble_nus.h"

#include "app_uart.h"
#include "app_util_platform.h"
#include "bsp.h"
#include "bsp_btn_ble.h"

#include "app_scheduler.h"
#include "app_timer_appsh.h"
#include "sd_mmc_start.h"
#include "ff.h"
#include "nrf_peripherals.h"
#ifdef ADC_PRESENT
#include "nrf_drv_adc.h"
#else
#include "nrf_drv_saadc.h"
#endif //ADC_PRESENT

#define NRF_LOG_MODULE_NAME "APP"
//#include "diskio_blkdev.h"
#include "ff.h"
//#include "nrf_block_dev_sdc.h"
#include "nrf_delay.h"
#include "nrf_drv_spi.h"
#include "nrf_drv_twi.h"
#include "nrf_drv_wdt.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"

#include <math.h>
uint16_t timeout_twi = 5;

//#define SDC_SCK_PIN 4   //ARDUINO_13_PIN  ///< SDC serial clock (SCK) pin.
//#define SDC_MOSI_PIN 12 //ARDUINO_11_PIN  ///< SDC serial data in (DI) pin.
//#define SDC_MISO_PIN 3  //ARDUINO_12_PIN  ///< SDC serial data out (DO) pin.
//#define SDC_CS_PIN 10   //ARDUINO_10_PIN  ///< SDC chip select (CS) pin.
//#define FILE_NAME "A_data.txt"
uint8_t wr_dat[30];

extern uint8_t font_r;
extern uint8_t font_g;
extern uint8_t font_b;

uint8_t hour = 0;
uint8_t mins = 0;
uint8_t secs = 0;

uint32_t temps_max = 0;
uint32_t temps_min = 90000;

uint32_t pres_max = 0;
uint32_t pres_min = 900000;

void Set_Font_Color_RGB(uint8_t red,uint8_t green,uint8_t blue){
  font_r = red;
  font_g = green;
  font_b = blue;
}

uint8_t connection=0;
#define IS_SRVC_CHANGED_CHARACT_PRESENT 0 /**< Include the service_changed characteristic. If not enabled, the server's database cannot be changed for the lifetime of the device. */

#if (NRF_SD_BLE_API_VERSION == 3)
#define NRF_BLE_MAX_MTU_SIZE GATT_MTU_SIZE_DEFAULT /**< MTU size used in the softdevice enabling and to reply to a BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST event. */
#endif

#define APP_FEATURE_NOT_SUPPORTED BLE_GATT_STATUS_ATTERR_APP_BEGIN + 2 /**< Reply when unsupported features are requested. */

#define CENTRAL_LINK_COUNT 0    /**< Number of central links used by the application. When changing this number remember to adjust the RAM settings*/
#define PERIPHERAL_LINK_COUNT 1 /**< Number of peripheral links used by the application. When changing this number remember to adjust the RAM settings*/

#define DEVICE_NAME "51s"                                 /**< Name of device. Will be included in the advertising data. */
#define NUS_SERVICE_UUID_TYPE BLE_UUID_TYPE_VENDOR_BEGIN /**< UUID type for the Nordic UART Service (vendor specific). */

#define APP_ADV_INTERVAL 64          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 40 ms). */
#define APP_ADV_TIMEOUT_IN_SECONDS 0 /**< The advertising timeout (in units of seconds). */

#define APP_TIMER_PRESCALER 0     /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_OP_QUEUE_SIZE 4 /**< Size of timer operation queues. */

#define BATTERY_LEVEL_MEAS_INTERVAL APP_TIMER_TICKS(2000, APP_TIMER_PRESCALER) /**< Battery level measurement interval (ticks). This value corresponds to 120 seconds. */

#define MIN_CONN_INTERVAL MSEC_TO_UNITS(20, UNIT_1_25_MS)                         /**< Minimum acceptable connection interval (20 ms), Connection interval uses 1.25 ms units. */
#define MAX_CONN_INTERVAL MSEC_TO_UNITS(75, UNIT_1_25_MS)                         /**< Maximum acceptable connection interval (75 ms), Connection interval uses 1.25 ms units. */
#define SLAVE_LATENCY 0                                                           /**< Slave latency. */
#define CONN_SUP_TIMEOUT MSEC_TO_UNITS(4000, UNIT_10_MS)                          /**< Connection supervisory timeout (4 seconds), Supervision Timeout uses 10 ms units. */
#define FIRST_CONN_PARAMS_UPDATE_DELAY APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER) /**< Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY APP_TIMER_TICKS(30000, APP_TIMER_PRESCALER) /**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT 3                                            /**< Number of attempts before giving up the connection parameter negotiation. */

#define DEAD_BEEF 0xDEADBEEF /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

#define ADC_REF_VOLTAGE_IN_MILLIVOLTS 600  /**< Reference voltage (in milli volts) used by ADC while doing conversion. */
#define ADC_PRE_SCALING_COMPENSATION 6     /**< The ADC is configured to use VDD with 1/3 prescaling as input. And hence the result of conversion is to be multiplied by 3 to get the actual value of the battery voltage.*/
#define DIODE_FWD_VOLT_DROP_MILLIVOLTS 270 /**< Typical forward voltage drop of the diode (Part no: SD103ATW-7-F) that is connected in series with the voltage supply. This is the voltage drop when the forward current is 1mA. Source: Data sheet of 'SURFACE MOUNT SCHOTTKY BARRIER DIODE ARRAY' available at www.diodes.com. */

#define ADC_REF_VBG_VOLTAGE_IN_MILLIVOLTS 1200 /**< Value in millivolts for voltage used as reference in ADC conversion on NRF51. */
#define ADC_INPUT_PRESCALER 3                  /**< Input prescaler for ADC convestion on NRF51. */
#define ADC_RES_10BIT 1024                     /**< Maximum digital value for 10-bit ADC conversion. */

#define SCHED_MAX_EVENT_DATA_SIZE MAX(APP_TIMER_SCHED_EVT_SIZE, \
    BLE_STACK_HANDLER_SCHED_EVT_SIZE) /**< Maximum size of scheduler events. */
#ifdef SVCALL_AS_NORMAL_FUNCTION
#define SCHED_QUEUE_SIZE 20 /**< Maximum number of events in the scheduler queue. More is needed in case of Serialization. */
#else
#define SCHED_QUEUE_SIZE 10 /**< Maximum number of events in the scheduler queue. */
#endif

#define UART_TX_BUF_SIZE 50//256 /**< UART TX buffer size. */
#define UART_RX_BUF_SIZE 50//256 /**< UART RX buffer size. */

static ble_nus_t m_nus;                                  /**< Structure to identify the Nordic UART Service. */
static uint16_t m_conn_handle = BLE_CONN_HANDLE_INVALID; /**< Handle of the current connection. */

static ble_uuid_t m_adv_uuids[] = {{BLE_UUID_NUS_SERVICE, NUS_SERVICE_UUID_TYPE}}; /**< Universally unique service identifier. */

uint16_t adc_dat = 0;
static ble_bas_t m_bas; /**< Structure used to identify the battery service. */
static volatile bool xfer_completed = false;
#define TWI_INSTANCE_ID 0
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);
static const nrf_drv_spi_t m_spi = NRF_DRV_SPI_INSTANCE(1);

APP_TIMER_DEF(m_battery_timer_id);
bool timer_flg = 0;
bool sd_flg = 0;
extern void display_string(uint16_t x_crd, uint16_t y_crd,const char* p_string,uint8_t background_r,uint8_t background_g,uint8_t background_b,uint8_t To_scrbuf);
/*static uint8_t dataBuffer[256] = { \
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,	\
	0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,	\
	0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,	\
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,	\
	
	0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,	\
	0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,	\
	0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,	\
	0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,	\
	
	0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,	\
	0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F,	\
	0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,	\
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,	\
	
	0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,	\
	0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5A, 0x5B, 0x5C, 0x5D, 0x5E, 0x5F,	\
	0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,	\
	0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B, 0x7C, 0x7D, 0x7E, 0x7F,	\

};*/

/**@brief Macro to convert the result of ADC conversion in millivolts.
 *
 * @param[in]  ADC_VALUE   ADC result.
 *
 * @retval     Result converted to millivolts.
 */
#ifdef ADC_PRESENT
#define ADC_RESULT_IN_MILLI_VOLTS(ADC_VALUE) \
  ((((ADC_VALUE)*ADC_REF_VBG_VOLTAGE_IN_MILLIVOLTS) / ADC_RES_10BIT) * ADC_INPUT_PRESCALER)
#else // SAADC_PRESENT
#define ADC_RESULT_IN_MILLI_VOLTS(ADC_VALUE) \
  ((((ADC_VALUE)*ADC_REF_VOLTAGE_IN_MILLIVOLTS) / ADC_RES_10BIT) * ADC_PRE_SCALING_COMPENSATION)
#endif // ADC_PRESENT

#ifdef ADC_PRESENT
static nrf_adc_value_t adc_buf[1];
#else
static nrf_saadc_value_t adc_buf[2];
#endif //ADC_PRESENT

#ifdef ADC_PRESENT

/**@brief Function for handling the ADC driver eevent.
 *
 * @details  This function will fetch the conversion result from the ADC, convert the value into
 *           percentage and send it to peer.
 */

void adc_event_handler(nrf_drv_adc_evt_t const *p_event) {
  if (p_event->type == NRF_DRV_ADC_EVT_DONE) {
    nrf_adc_value_t adc_result;
    uint16_t batt_lvl_in_milli_volts;
    uint8_t percentage_batt_lvl;
    uint32_t err_code;

    adc_result = p_event->data.done.p_buffer[0];
    adc_dat = adc_result;
    err_code = nrf_drv_adc_buffer_convert(p_event->data.done.p_buffer, 1);
    APP_ERROR_CHECK(err_code);

    batt_lvl_in_milli_volts = ADC_RESULT_IN_MILLI_VOLTS(adc_result) +
                              DIODE_FWD_VOLT_DROP_MILLIVOLTS;
    percentage_batt_lvl = battery_level_in_percent(batt_lvl_in_milli_volts);
    
    secs+=2;
    if(secs>=60){secs=0; mins++;}
    if(mins>=60){mins=0; hour++;}
    if(hour>=24){hour=0;}

    NRF_LOG_INFO("Battery ADC value in Percentage %03d%%\n", percentage_batt_lvl);
    // err_code = ble_bas_battery_level_update(&m_bas, percentage_batt_lvl);
    if (
        (err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_PACKETS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)) {
      APP_ERROR_HANDLER(err_code);
    }

    nrf_drv_adc_uninit();
  }
}

#else // SAADC_PRESENT
/**@brief Function for handling the ADC interrupt.
 *
 * @details  This function will fetch the conversion result from the ADC, convert the value into
 *           percentage and send it to peer.
 */
void saadc_event_handler(nrf_drv_saadc_evt_t const *p_event) {
  if (p_event->type == NRF_DRV_SAADC_EVT_DONE) {
    nrf_saadc_value_t adc_result;
    uint16_t batt_lvl_in_milli_volts;
    uint8_t percentage_batt_lvl;
    uint32_t err_code;

    adc_result = p_event->data.done.p_buffer[0];

    err_code = nrf_drv_saadc_buffer_convert(p_event->data.done.p_buffer, 1);
    APP_ERROR_CHECK(err_code);

    batt_lvl_in_milli_volts = ADC_RESULT_IN_MILLI_VOLTS(adc_result) +
                              DIODE_FWD_VOLT_DROP_MILLIVOLTS;
    percentage_batt_lvl = battery_level_in_percent(batt_lvl_in_milli_volts);

    err_code = ble_bas_battery_level_update(&m_bas, percentage_batt_lvl);
    if (
        (err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_PACKETS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)) {
      APP_ERROR_HANDLER(err_code);
    }
  }
}

#endif // ADC_PRESENT

/**@brief Function for configuring ADC to do battery level conversion.
 */
static void adc_configure(void) {
#ifdef ADC_PRESENT
  ret_code_t err_code = nrf_drv_adc_init(NULL, adc_event_handler);
  APP_ERROR_CHECK(err_code);

  static nrf_drv_adc_channel_t channel =
      NRF_DRV_ADC_DEFAULT_CHANNEL(NRF_ADC_CONFIG_INPUT_DISABLED);
  // channel.config.config.input = NRF_ADC_CONFIG_SCALING_SUPPLY_ONE_THIRD;
  channel.config.config.input = (uint32_t)NRF_ADC_CONFIG_SCALING_SUPPLY_ONE_THIRD;
  nrf_drv_adc_channel_enable(&channel);

  err_code = nrf_drv_adc_buffer_convert(&adc_buf[0], 1);
  APP_ERROR_CHECK(err_code);
#else  //  SAADC_PRESENT
  ret_code_t err_code = nrf_drv_saadc_init(NULL, saadc_event_handler);
  APP_ERROR_CHECK(err_code);

  nrf_saadc_channel_config_t config =
      NRF_DRV_SAADC_DEFAULT_CHANNEL_CONFIG_SE(NRF_SAADC_INPUT_VDD);
  err_code = nrf_drv_saadc_channel_init(0, &config);
  APP_ERROR_CHECK(err_code);

  err_code = nrf_drv_saadc_buffer_convert(&adc_buf[0], 1);
  APP_ERROR_CHECK(err_code);

  err_code = nrf_drv_saadc_buffer_convert(&adc_buf[1], 1);
  APP_ERROR_CHECK(err_code);
#endif //ADC_PRESENT
}

/**@brief Function for handling the Battery measurement timer timeout.
 *
 * @details This function will be called each time the battery level measurement timer expires.
 *          This function will start the ADC.
 *
 * @param[in] p_context   Pointer used for passing some arbitrary information (context) from the
 *                        app_start_timer() call to the timeout handler.
 */
static void battery_level_meas_timeout_handler(void *p_context) {
  UNUSED_PARAMETER(p_context);
#ifdef ADC_PRESENT
  adc_configure();
  nrf_drv_adc_sample();
  timer_flg = 1;
#else  // SAADC_PRESENT
  uint32_t err_code;
  err_code = nrf_drv_saadc_sample();
  APP_ERROR_CHECK(err_code);
#endif // ADC_PRESENT
}

/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t *p_file_name) {
  app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

/**@brief Function for the GAP initialization.
 *
 * @details This function will set up all the necessary GAP (Generic Access Profile) parameters of
 *          the device. It also sets the permissions and appearance.
 */
static void gap_params_init(void) {
  uint32_t err_code;
  ble_gap_conn_params_t gap_conn_params;
  ble_gap_conn_sec_mode_t sec_mode;

  BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

  err_code = sd_ble_gap_device_name_set(&sec_mode,
      (const uint8_t *)DEVICE_NAME,
      strlen(DEVICE_NAME));
  APP_ERROR_CHECK(err_code);

  memset(&gap_conn_params, 0, sizeof(gap_conn_params));

  gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
  gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
  gap_conn_params.slave_latency = SLAVE_LATENCY;
  gap_conn_params.conn_sup_timeout = CONN_SUP_TIMEOUT;

  err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
  APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling the data from the Nordic UART Service.
 *
 * @details This function will process the data received from the Nordic UART BLE Service and send
 *          it to the UART module.
 *
 * @param[in] p_nus    Nordic UART Service structure.
 * @param[in] p_data   Data to be send to UART module.
 * @param[in] length   Length of the data.
 */
/**@snippet [Handling the data received over BLE] */
static void nus_data_handler(ble_nus_t *p_nus, uint8_t *p_data, uint16_t length) {
if(length>3){

  if(p_data[0]=='h'){hour = (p_data[1]-48)*10+(p_data[2]-48);}
  else if(p_data[0]=='m'){mins = (p_data[1]-48)*10+(p_data[2]-48);}

}/*
  for (uint32_t i = 0; i < length; i++) {
    while (app_uart_put(p_data[i]) != NRF_SUCCESS)
      ;
  }
  while (app_uart_put('\r') != NRF_SUCCESS)
    ;
  while (app_uart_put('\n') != NRF_SUCCESS)
    ;*/
}

static void services_init(void) {
  uint32_t err_code;
  ble_nus_init_t nus_init;

  memset(&nus_init, 0, sizeof(nus_init));

  nus_init.data_handler = nus_data_handler;

  err_code = ble_nus_init(&m_nus, &nus_init);
  APP_ERROR_CHECK(err_code);

  // bas_init();
}

/**@brief Function for starting timers.
 */
static void timers_start(void) {
  uint32_t err_code;

  err_code = app_timer_start(m_battery_timer_id, BATTERY_LEVEL_MEAS_INTERVAL, NULL);
  APP_ERROR_CHECK(err_code);
}

/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module.
 */
static void timers_init(void) {
  uint32_t err_code;

  // Initialize timer module, making it use the scheduler.
  APP_TIMER_APPSH_INIT(APP_TIMER_PRESCALER, APP_TIMER_OP_QUEUE_SIZE, true);

  // Create battery timer.
  err_code = app_timer_create(&m_battery_timer_id,
      APP_TIMER_MODE_REPEATED,
      battery_level_meas_timeout_handler);
  APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling an event from the Connection Parameters Module.
 *
 * @details This function will be called for all events in the Connection Parameters Module
 *          which are passed to the application.
 *
 * @note All this function does is to disconnect. This could have been done by simply setting
 *       the disconnect_on_fail config parameter, but instead we use the event handler
 *       mechanism to demonstrate its use.
 *
 * @param[in] p_evt  Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t *p_evt) {
  uint32_t err_code;

  if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED) {
    err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
    APP_ERROR_CHECK(err_code);
  }
}

/**@brief Function for handling errors from the Connection Parameters module.
 *
 * @param[in] nrf_error  Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error) {
  APP_ERROR_HANDLER(nrf_error);
}

/**@brief Function for initializing the Connection Parameters module.
 */
static void conn_params_init(void) {
  uint32_t err_code;
  ble_conn_params_init_t cp_init;

  memset(&cp_init, 0, sizeof(cp_init));

  cp_init.p_conn_params = NULL;
  cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
  cp_init.next_conn_params_update_delay = NEXT_CONN_PARAMS_UPDATE_DELAY;
  cp_init.max_conn_params_update_count = MAX_CONN_PARAMS_UPDATE_COUNT;
  cp_init.start_on_notify_cccd_handle = BLE_GATT_HANDLE_INVALID;
  cp_init.disconnect_on_fail = false;
  cp_init.evt_handler = on_conn_params_evt;
  cp_init.error_handler = conn_params_error_handler;

  err_code = ble_conn_params_init(&cp_init);
  APP_ERROR_CHECK(err_code);
}

/**@brief Function for putting the chip into sleep mode.
 *
 * @note This function will not return.
 */
static void sleep_mode_enter(void) {

}

/**@brief Function for handling advertising events.
 *
 * @details This function will be called for advertising events which are passed to the application.
 *
 * @param[in] ble_adv_evt  Advertising event.
 */
static void on_adv_evt(ble_adv_evt_t ble_adv_evt) {
  uint32_t err_code;

  switch (ble_adv_evt) {
  case BLE_ADV_EVT_FAST:
    //     err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
    //    APP_ERROR_CHECK(err_code);
    break;
  case BLE_ADV_EVT_IDLE:
    //  sleep_mode_enter();
    break;
  default:
    break;
  }
}

/**@brief Function for the application's SoftDevice event handler.
 *
 * @param[in] p_ble_evt SoftDevice event.
 */
static void on_ble_evt(ble_evt_t *p_ble_evt) {
  uint32_t err_code;

  switch (p_ble_evt->header.evt_id) {
  case BLE_GAP_EVT_CONNECTED:
  connection=1;
    //err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
    //APP_ERROR_CHECK(err_code);
    m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;

    NRF_LOG_INFO("BLE Connected with Handle = %x\n", m_conn_handle);
    break; // BLE_GAP_EVT_CONNECTED
  case BLE_GAP_EVT_DISCONNECTED:
    connection=0;
    //NVIC_SystemReset();
    // err_code = bsp_indication_set(BSP_INDICATE_IDLE);
    // APP_ERROR_CHECK(err_code);
    m_conn_handle = BLE_CONN_HANDLE_INVALID;

    // NRF_LOG_INFO("BLE Disconnection\n");
    break; // BLE_GAP_EVT_DISCONNECTED

  case BLE_EVT_TX_COMPLETE:

    break; // BLE_EVT_TX_COMPLETE

  case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
    // Pairing not supported
    err_code = sd_ble_gap_sec_params_reply(m_conn_handle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
    APP_ERROR_CHECK(err_code);
    break; // BLE_GAP_EVT_SEC_PARAMS_REQUEST

  case BLE_GATTS_EVT_SYS_ATTR_MISSING:
    // No system attributes have been stored.
    err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
    APP_ERROR_CHECK(err_code);
    break; // BLE_GATTS_EVT_SYS_ATTR_MISSING

  case BLE_GATTC_EVT_TIMEOUT:
    // Disconnect on GATT Client timeout event.
    err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
        BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
    APP_ERROR_CHECK(err_code);
    break; // BLE_GATTC_EVT_TIMEOUT

  case BLE_GATTS_EVT_TIMEOUT:
    // Disconnect on GATT Server timeout event.
    err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
        BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
    APP_ERROR_CHECK(err_code);
    break; // BLE_GATTS_EVT_TIMEOUT

  case BLE_EVT_USER_MEM_REQUEST:
    err_code = sd_ble_user_mem_reply(p_ble_evt->evt.gattc_evt.conn_handle, NULL);
    APP_ERROR_CHECK(err_code);
    break; // BLE_EVT_USER_MEM_REQUEST

  case BLE_GATTS_EVT_RW_AUTHORIZE_REQUEST: {
    ble_gatts_evt_rw_authorize_request_t req;
    ble_gatts_rw_authorize_reply_params_t auth_reply;

    req = p_ble_evt->evt.gatts_evt.params.authorize_request;

    if (req.type != BLE_GATTS_AUTHORIZE_TYPE_INVALID) {
      if ((req.request.write.op == BLE_GATTS_OP_PREP_WRITE_REQ) ||
          (req.request.write.op == BLE_GATTS_OP_EXEC_WRITE_REQ_NOW) ||
          (req.request.write.op == BLE_GATTS_OP_EXEC_WRITE_REQ_CANCEL)) {
        if (req.type == BLE_GATTS_AUTHORIZE_TYPE_WRITE) {
          auth_reply.type = BLE_GATTS_AUTHORIZE_TYPE_WRITE;
        } else {
          auth_reply.type = BLE_GATTS_AUTHORIZE_TYPE_READ;
        }
        auth_reply.params.write.gatt_status = APP_FEATURE_NOT_SUPPORTED;
        err_code = sd_ble_gatts_rw_authorize_reply(p_ble_evt->evt.gatts_evt.conn_handle,
            &auth_reply);
        APP_ERROR_CHECK(err_code);
      }
    }
  } break; // BLE_GATTS_EVT_RW_AUTHORIZE_REQUEST

#if (NRF_SD_BLE_API_VERSION == 3)
  case BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST:
    err_code = sd_ble_gatts_exchange_mtu_reply(p_ble_evt->evt.gatts_evt.conn_handle,
        NRF_BLE_MAX_MTU_SIZE);
    APP_ERROR_CHECK(err_code);
    break; // BLE_GATTS_EVT_EXCHANGE_MTU_REQUEST
#endif

  default:
    // No implementation needed.
    break;
  }
}

/**@brief Function for dispatching a SoftDevice event to all modules with a SoftDevice
 *        event handler.
 *
 * @details This function is called from the SoftDevice event interrupt handler after a
 *          SoftDevice event has been received.
 *
 * @param[in] p_ble_evt  SoftDevice event.
 */
static void ble_evt_dispatch(ble_evt_t *p_ble_evt) {
  ble_conn_params_on_ble_evt(p_ble_evt);
  ble_nus_on_ble_evt(&m_nus, p_ble_evt);
  on_ble_evt(p_ble_evt);
  ble_advertising_on_ble_evt(p_ble_evt);
  //  bsp_btn_ble_on_ble_evt(p_ble_evt);
  //  ble_bas_on_ble_evt(&m_bas, p_ble_evt);
}

/**@brief   Function for dispatching a system event to interested modules.
 *
 * @details This function is called from the System event interrupt handler after a system
 *          event has been received.
 *
 * @param[in]   sys_evt   System stack event.
 */
static void sys_evt_dispatch(uint32_t sys_evt) {

  ble_advertising_on_sys_evt(sys_evt);
}

/**@brief Function for the SoftDevice initialization.
 *
 * @details This function initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void) {
  uint32_t err_code;

  nrf_clock_lf_cfg_t clock_lf_cfg = NRF_CLOCK_LFCLKSRC;

  // Initialize SoftDevice.
  SOFTDEVICE_HANDLER_INIT(&clock_lf_cfg, NULL);

  ble_enable_params_t ble_enable_params;
  err_code = softdevice_enable_get_default_config(CENTRAL_LINK_COUNT,
      PERIPHERAL_LINK_COUNT,
      &ble_enable_params);
  APP_ERROR_CHECK(err_code);

  //Check the ram settings against the used number of links
  CHECK_RAM_START_ADDR(CENTRAL_LINK_COUNT, PERIPHERAL_LINK_COUNT);

  // Enable BLE stack.
#if (NRF_SD_BLE_API_VERSION == 3)
  ble_enable_params.gatt_enable_params.att_mtu = NRF_BLE_MAX_MTU_SIZE;
#endif
  err_code = softdevice_enable(&ble_enable_params);
  APP_ERROR_CHECK(err_code);

  // Subscribe for BLE events.
  err_code = softdevice_ble_evt_handler_set(ble_evt_dispatch);
  APP_ERROR_CHECK(err_code);

  // Register with the SoftDevice handler module for BLE events.
  err_code = softdevice_sys_evt_handler_set(sys_evt_dispatch);
  APP_ERROR_CHECK(err_code);
}

/**@brief Function for the Event Scheduler initialization.
 */
static void scheduler_init(void) {
  APP_SCHED_INIT(SCHED_MAX_EVENT_DATA_SIZE, SCHED_QUEUE_SIZE);
}

static void advertising_init(void) {
  uint32_t err_code;
  ble_advdata_t advdata;
  ble_advdata_t scanrsp;
  ble_adv_modes_config_t options;

  // Build advertising data struct to pass into @ref ble_advertising_init.
  memset(&advdata, 0, sizeof(advdata));
  advdata.name_type = BLE_ADVDATA_FULL_NAME;
  advdata.include_appearance = false;
  advdata.flags = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;

  memset(&scanrsp, 0, sizeof(scanrsp));
  scanrsp.uuids_complete.uuid_cnt = sizeof(m_adv_uuids) / sizeof(m_adv_uuids[0]);
  scanrsp.uuids_complete.p_uuids = m_adv_uuids;

  memset(&options, 0, sizeof(options));
  options.ble_adv_fast_enabled = true;
  options.ble_adv_fast_interval = APP_ADV_INTERVAL;
  options.ble_adv_fast_timeout = APP_ADV_TIMEOUT_IN_SECONDS;

  err_code = ble_advertising_init(&advdata, &scanrsp, &options, on_adv_evt, NULL);
  APP_ERROR_CHECK(err_code);
}


static void power_manage(void) {
  uint32_t err_code = sd_app_evt_wait();
  APP_ERROR_CHECK(err_code);
}

void twi_init(void) {
  ret_code_t err_code;

  const nrf_drv_twi_config_t twi_config = {
      .scl = 1,//ARDUINO_SCL_PIN,
      .sda = 0,//ARDUINO_SDA_PIN,
      .frequency = NRF_TWI_FREQ_100K,
      .interrupt_priority = APP_IRQ_PRIORITY_HIGH,
      .clear_bus_init = true};

  err_code = nrf_drv_twi_init(&m_twi, &twi_config, NULL, NULL);
  APP_ERROR_CHECK(err_code);

  nrf_drv_twi_enable(&m_twi);
}
void spi_init(void) {
  ret_code_t err_code;

  const nrf_drv_spi_config_t spi_config = {
    .sck_pin      = 25,                \
    .mosi_pin     = 24,                \
    .miso_pin     = 23,                \
    .ss_pin       = NRF_DRV_SPI_PIN_NOT_USED,                \
    .irq_priority = SPI_DEFAULT_CONFIG_IRQ_PRIORITY,         \
    .orc          = 0xFF,                                    \
    .frequency    = NRF_DRV_SPI_FREQ_8M,                     \
    .mode         = NRF_DRV_SPI_MODE_0,                      \
    .bit_order    = NRF_DRV_SPI_BIT_ORDER_MSB_FIRST,   
      
      };

  err_code = nrf_drv_spi_init(&m_spi, &spi_config, NULL);
  APP_ERROR_CHECK(err_code);

}

//---------------------------------------------BME280-------------------------------------------------------

uint16_t BME280_Read_Coff(uint8_t reg) {

  uint8_t dats[] = {reg};
  nrf_drv_twi_tx(&m_twi, 0x76, dats, sizeof(dats), true);
  nrf_delay_ms(timeout_twi);
  uint8_t Buf[2] = {0, 0};
  nrf_drv_twi_rx(&m_twi, 0x76, (uint8_t *)&Buf, sizeof(Buf));
  nrf_delay_ms(timeout_twi);
  uint16_t value = Buf[0];
  value <<= 8;
  value |= Buf[1];
  return ((value >> 8) | (value << 8));
}
uint8_t BME280_Read_Cof(uint8_t reg) {

  uint8_t dats[] = {reg};
  nrf_drv_twi_tx(&m_twi, 0x76, dats, sizeof(dats), true);
  nrf_delay_ms(timeout_twi);
  uint8_t Buf[1] = {0};
  nrf_drv_twi_rx(&m_twi, 0x76, (uint8_t *)&Buf, sizeof(Buf));
  nrf_delay_ms(timeout_twi);
  uint8_t value = Buf[0];

  return value;
}

uint32_t BME280_Termo(uint16_t conf0, int16_t conf1, int16_t conf2) {

  uint8_t dats[] = {0xFA};
  nrf_drv_twi_tx(&m_twi, 0x76, dats, sizeof(dats), true);
  nrf_delay_ms(timeout_twi);
  uint8_t Buf[3] = {0, 0, 0};
  nrf_drv_twi_rx(&m_twi, 0x76, (uint8_t *)&Buf, sizeof(Buf));
  nrf_delay_ms(timeout_twi);
  uint32_t value = Buf[0];
  value <<= 8;
  value |= Buf[1];
  value <<= 8;
  value |= Buf[2];
  value >>= 4;

  uint32_t var1 = ((((value >> 3) - ((int32_t)conf0 << 1))) *
                      ((int32_t)conf1)) >>
                  11;

  uint32_t var2 = (((((value >> 4) - ((int32_t)conf0)) *
                        ((value >> 4) - ((int32_t)conf0))) >>
                       12) *
                      ((int32_t)conf2)) >>
                  14;

  uint32_t t_fine = var1 + var2;

  return t_fine;
}

/*float BME280_Humid(uint32_t t_fine, uint16_t reg0, int16_t reg1, uint16_t reg2, uint16_t reg3, uint16_t reg4, int16_t reg5){

  uint8_t dats[]={0xFD};
  nrf_drv_twi_tx(&m_twi,0x76 ,dats , sizeof(dats), true); //__WFE();
  uint8_t Buf[2]={0,0};
  nrf_drv_twi_rx(&m_twi, 0x76, (uint8_t*)&Buf, sizeof(Buf));// __WFE();
    uint16_t value = Buf[0];
    value <<= 8;
    value |= Buf[1];


  int32_t v_x1_u32r;

  v_x1_u32r = (t_fine - ((int32_t)76800));

  v_x1_u32r = (((((value << 14) - (((int32_t)reg3) << 20) -
                  (((int32_t)reg4) * v_x1_u32r)) +
                 ((int32_t)16384)) >>
                15) *
               (((((((v_x1_u32r * ((int32_t)reg5)) >> 10) *
                    (((v_x1_u32r * ((int32_t)reg2)) >> 11) +
                     ((int32_t)32768))) >>
                   10) +
                  ((int32_t)2097152)) *
                     ((int32_t)reg1) +
                 8192) >>
                14));

  v_x1_u32r = (v_x1_u32r - (((((v_x1_u32r >> 15) * (v_x1_u32r >> 15)) >> 7) *
                             ((int32_t)reg0)) >>
                            4));

  v_x1_u32r = (v_x1_u32r < 0) ? 0 : v_x1_u32r;
  v_x1_u32r = (v_x1_u32r > 419430400) ? 419430400 : v_x1_u32r;
  float h = (v_x1_u32r >> 12);
  return h / 1024.0;

}*/

float BME280_Preass(uint32_t t_fine, uint16_t reg0, int16_t reg1, int16_t reg2, int16_t reg3, int16_t reg4, int16_t reg5, int16_t reg6, int16_t reg7, int16_t reg8) {

  int64_t var1, var2, p;

  uint8_t dats[] = {0xF7};
  nrf_drv_twi_tx(&m_twi, 0x76, dats, sizeof(dats), true);
  nrf_delay_ms(timeout_twi);
  uint8_t Buf[3] = {0, 0, 0};
  nrf_drv_twi_rx(&m_twi, 0x76, (uint8_t *)&Buf, sizeof(Buf));
  nrf_delay_ms(timeout_twi);
  uint32_t value = Buf[0];
  value <<= 8;
  value |= Buf[1];
  value <<= 8;
  value |= Buf[2];
  value >>= 4;

  int32_t adc_P = value;
  if (adc_P == 0x800000) // value in case pressure measurement was disabled
    return 0;
  //adc_P >>= 4;

  var1 = ((int64_t)t_fine) - 128000;
  var2 = var1 * var1 * (int64_t)reg5;
  var2 = var2 + ((var1 * (int64_t)reg4) << 17);
  var2 = var2 + (((int64_t)reg3) << 35);
  var1 = ((var1 * var1 * (int64_t)reg2) >> 8) +
         ((var1 * (int64_t)reg1) << 12);
  var1 =
      (((((int64_t)1) << 47) + var1)) * ((int64_t)reg0) >> 33;

  if (var1 == 0) {
    return 0; // avoid exception caused by division by zero
  }
  p = 1048576 - adc_P;
  p = (((p << 31) - var2) * 3125) / var1;
  var1 = (((int64_t)reg8) * (p >> 13) * (p >> 13)) >> 25;
  var2 = (((int64_t)reg7) * p) >> 19;

  p = ((p + var1 + var2) >> 8) + (((int64_t)reg6) << 4);
  return (float)p / 256;
}

//---------------------------------------------BME280-------------------------------------------------------

void WDT_handler(){

__NOP();

}

void spi_write(uint8_t param1,uint8_t param2){

uint8_t data_out[1];
uint8_t data_in[1];
data_out[0]=param2;
nrf_drv_spi_transfer(&m_spi,data_out,1,data_in,1);
//nrf_delay_us(100);
}
uint8_t spi_read(uint8_t param1){
uint8_t data_out[1];
uint8_t data_in[1];
data_out[0]=0xFF;
nrf_drv_spi_transfer(&m_spi,data_out,1,data_in,1);
return data_in[1];
}
void pio_clear(uint16_t pin){
  nrf_gpio_pin_clear(pin);
}
void pio_set(uint16_t pin){
  nrf_gpio_pin_set(pin);
}
void msleep(uint32_t delay){
  nrf_delay_ms(delay);
}
/**@brief Application main function.
 */

void display_start(void){
	
	ili9341_init();
	ili9341_backlight_off();
	ili9341_backlight_on();
	
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(129,
	129);
	ili9341_duplicate_pixel(ILI9341_COLOR(0,0,0), 129*129);
}
uint16_t bar[90];
void draw_bar(uint32_t data){
		ili9341_set_top_left_limit(110-90, 5);
		ili9341_set_bottom_right_limit(110 , 5 );
		for(int i=0;i<90;i++){

			if(data*3/110>i){
				
				bar[i] = ILI9341_COLOR(i+150, 0, 0);
			}
			else{
				bar[i] = ILI9341_COLOR(0, 0, 0);
			}
		}
		ili9341_copy_pixels_to_screen(bar,90);
        for(int l=0;l<4;l++){
                ili9341_set_top_left_limit(110-90, 5+l);
		ili9341_set_bottom_right_limit(110 , 5+l );
                ili9341_copy_pixels_to_screen(bar,90);
              }
}

void draw_bar2(uint32_t data,uint8_t rr,uint8_t gg,uint8_t bb,uint8_t xx,uint8_t yy,uint32_t mx,uint32_t mn){

float df = (mx-mn)/90;
for(int l=0;l<4;l++){
                uint16_t pixs[1];
		for(int i=0;i<90;i++){
                uint8_t y = yy+l-10*sin(3.14*(i)/90);
		ili9341_set_top_left_limit(xx+1-i, y);
		ili9341_set_bottom_right_limit(xx-i , y );
			if(data>(i*df+mn)){
				
				pixs[0] = ILI9341_COLOR(i+rr, gg, bb);
			}
			else{
				pixs[0] = ILI9341_COLOR(0, 30, 30);
			}
                        ili9341_copy_pixels_to_screen(pixs,1);
		}
		}

}

void display_update(uint32_t data,uint32_t data2){
	
        char t_data[10]={0};
        sprintf(t_data,"%d\0",data);

        if(data>3000){Set_Font_Color_RGB(255,0,0);}
        else{Set_Font_Color_RGB(0,100,222);}
        draw_bar2(data,150,0,0,110,20,temps_max,temps_min);
        display_string(100, 25,t_data,0,0,0,0);
        sprintf(t_data,"%d\0",data2);
        Set_Font_Color_RGB(0,100,222);
        draw_bar2(data2,0,150,0,110,60,pres_max,pres_min);
        display_string(100, 65,t_data,0,10,10,0);

}



FRESULT res;
FATFS fs;
FIL file_object;

uint8_t fatfs_write(char * write_words)
{
        uint8_t wrf=0;
        char test_file_name[] = "sc.txt";
        memset(&fs, 0, sizeof(FATFS));
        uint8_t drv[1] = {0};
        res = f_mount(&fs, drv, 1);
                if (res == 0)
        { NRF_LOG_INFO("mount ok\n");}
        else{NRF_LOG_INFO("mount nok %d\n",res);
        }

        res = f_open(&file_object, (char const *)test_file_name, FA_OPEN_ALWAYS | FA_WRITE);

        if (res == 0)
        {

                res = f_lseek(&file_object, file_object.fsize);

                uint8_t bytesrw = 0;
                wrf = 1;
                f_puts(write_words, &file_object);

                f_close(&file_object);
        }
        //  f_close(&file_object);
        f_mount(0, 0, 1);
        return wrf;
}

uint8_t fatfs_bitmap(void)
{
        uint8_t wrf=0;
        char test_file_name[] = "tlf2.bmp";
        memset(&fs, 0, sizeof(FATFS));
        uint8_t drv[1] = {0};
        res = f_mount(&fs, drv, 1);
                if (res == 0)
        { NRF_LOG_INFO("mount ok\n");}
        else{NRF_LOG_INFO("mount nok %d\n",res);
        }

        res = f_open(&file_object, (char const *)test_file_name, FA_OPEN_EXISTING | FA_READ);

        if (res == 0)
        {

			unsigned int confirm;
			uint32_t s_adr=0;
                        char buf[60]={0};
			f_lseek(&file_object, 0x0A);
			f_read(&file_object,buf,4,&confirm);
			s_adr = (buf[3]<<24)| (buf[2]<<16)| (buf[1]<<8)| (buf[0]);
			f_lseek(&file_object,s_adr); 
                uint8_t bytesrw = 0;
                wrf = 1;
                uint16_t pixs[1];
                for(int lli=0;lli<128;lli++){nrf_drv_wdt_feed();
                  for(int llj=0;llj<128;llj++){
                  		ili9341_set_top_left_limit(127-llj, 127-lli);
                                ili9341_set_bottom_right_limit(127-llj+1 , 127-lli );
                                f_read(&file_object,buf,3,&confirm);
                            if(llj<=130){
				pixs[0] = ILI9341_COLOR(buf[2], buf[1], buf[0]);
                                ili9341_copy_pixels_to_screen(pixs,1);
                                }
                  
                  }
                }
                f_close(&file_object);
        }
        //  f_close(&file_object);
        f_mount(0, 0, 1);
        return wrf;
}

// fatfs microsd write
void GPIO_SR(uint8_t pin, uint8_t state)
{

        if (state)
        {
                nrf_gpio_pin_set(pin);
        }
        else
        {
                nrf_gpio_pin_clear(pin);
        }
}
void spi_read_single(uint8_t *data)
{
uint8_t data_out[1];
uint8_t data_in[1];
data_out[0]=0xFF;
nrf_drv_spi_transfer(&m_spi,data_out,1,data_in,1);
//return data_in[1];
*data = (uint8_t)data_in[0];
}
void spi_write_single(uint8_t data)
{
uint8_t data_out[1];
uint8_t data_in[1];
data_out[0]=data;
nrf_drv_spi_transfer(&m_spi,data_out,1,data_in,1);
}


int main(void) {
  uint32_t err_code;
  bool erase_bonds;

  // Initialize.
  err_code = NRF_LOG_INIT(NULL);

  nrf_gpio_cfg_output(2);
  nrf_gpio_cfg_output(30);
  nrf_gpio_cfg_output(22);
  spi_init();
  display_start();
    nrf_gpio_pin_set(30);
        sd_mmc_stack_init();
        uint8_t fs_answer=0;fatfs_bitmap();
  // Initialize.
  timers_init();
  nrf_drv_wdt_config_t const pconf = NRF_DRV_WDT_DEAFULT_CONFIG;
  nrf_drv_wdt_init(&pconf, WDT_handler);
  twi_init();


  ble_stack_init();
 // adc_configure(); in the timers init
  scheduler_init();
  nrf_gpio_cfg_output(18);
  nrf_gpio_pin_toggle(18);
  
  gap_params_init();
  services_init();
  advertising_init();
  conn_params_init();
  timers_start();

  err_code = ble_advertising_start(BLE_ADV_MODE_FAST);


  NRF_LOG_INFO("SDK 12.3 Example with UART Start!\n");
  nrf_drv_wdt_channel_alloc(0);
  nrf_drv_wdt_enable();

        fs_answer = fatfs_write("\n");
        if(fs_answer==1){
                //display_string(100, 100,"SD_OK",100,200,100,0);
                
                }
        else{  // display_string(100, 100,"ERR",100,200,100,0);
        }
 NRF_LOG_INFO("SDK  Start!\n");

  for (;;) {
  nrf_gpio_pin_toggle(18);
    nrf_drv_wdt_feed();

    if (timer_flg) {

      char buf[20];

      uint16_t confs[3];
      uint8_t datt[2] = {0xE0, 0xB6};
      nrf_drv_twi_tx(&m_twi, 0x76, datt, sizeof(datt), false);
      nrf_delay_ms(timeout_twi);
      datt[0] = 0xF4;
      datt[1] = 0x27;
      nrf_drv_twi_tx(&m_twi, 0x76, datt, sizeof(datt), false);
      nrf_delay_ms(timeout_twi);

      confs[0] = BME280_Read_Coff(0x88);
      nrf_delay_ms(timeout_twi);
      confs[1] = BME280_Read_Coff(0x8A);
      nrf_delay_ms(timeout_twi);
      confs[2] = BME280_Read_Coff(0x8C);
      nrf_delay_ms(timeout_twi);
      uint32_t termo = BME280_Termo(confs[0], confs[1], confs[2]);
      nrf_delay_ms(timeout_twi);
      int16_t cfg[9];
      uint16_t cf0;
      cf0 = BME280_Read_Coff(0x8E);
      nrf_delay_ms(timeout_twi);
      cfg[1] = (int16_t)BME280_Read_Coff(0x90);
      nrf_delay_ms(timeout_twi);
      cfg[2] = (int16_t)BME280_Read_Coff(0x92);
      nrf_delay_ms(timeout_twi);
      cfg[3] = (int16_t)BME280_Read_Coff(0x94);
      nrf_delay_ms(timeout_twi);
      cfg[4] = (int16_t)BME280_Read_Coff(0x96);
      nrf_delay_ms(timeout_twi);
      cfg[5] = (int16_t)BME280_Read_Coff(0x98);
      nrf_delay_ms(timeout_twi);
      cfg[6] = (int16_t)BME280_Read_Coff(0x9A);
      nrf_delay_ms(timeout_twi);
      cfg[7] = (int16_t)BME280_Read_Coff(0x9C);
      nrf_delay_ms(timeout_twi);
      cfg[8] = (int16_t)BME280_Read_Coff(0x9E);
      nrf_delay_ms(timeout_twi);
      float P = BME280_Preass(termo, cf0, cfg[1], cfg[2], cfg[3], cfg[4], cfg[5], cfg[6], cfg[7], cfg[8]);
      nrf_delay_ms(timeout_twi);
      float T = (termo * 5 + 128) >> 8;
      uint16_t a_sp = adc_dat;
      sprintf(buf, "%d", a_sp);
      uint8_t leng = strlen(buf);
      buf[leng + 1] = buf[leng];
      buf[leng] = ' ';
      strcpy(wr_dat, buf);
      a_sp = (uint16_t)T;
      buf[0] = '\0';
      sprintf(buf, "%d", a_sp);
      leng = strlen(buf);
      buf[leng + 1] = buf[leng];
      buf[leng] = '\t';
      strcat(wr_dat, buf);

      buf[0] = '\0';
      sprintf(buf, "%d \0", (uint32_t)P);

      strcat(wr_dat, buf);
      nrf_drv_wdt_feed();
      if (T<temps_min){temps_min = T;}
      if (T>temps_max){temps_max = T;}
      if (P<pres_min){pres_min = P;}
      if (P>pres_max){pres_max = P;}
      display_update((uint32_t)(T),(uint32_t)(P));
      char oppx[10];
      sprintf(oppx,"%02d:\0",hour);
      strcat(wr_dat, oppx);
      display_string(35, 119,oppx,0,0,0,0);
      sprintf(oppx,"%02d\0",mins);
      strcat(wr_dat, oppx);
      if(connection){
            ble_nus_send_file(&m_nus, wr_dat, strlen(wr_dat), 20);}
      strcat(wr_dat, "\n");
      display_string(15, 119,oppx,0,0,0,0);
      fatfs_write(wr_dat);
      timer_flg = 0;
    }

    app_sched_execute();

  }
}

/**
 * @}
 */