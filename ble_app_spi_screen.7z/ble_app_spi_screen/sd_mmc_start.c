/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file or main.c
 * to avoid loosing it when reconfiguring.
 */


#include "sd_mmc.h"
#include "diskio.h"
#include "conf_sd_mmc.h"


static uint8_t sd_mmc_block[512];

/*
 * Example
 */
void SDMMC_example(void)
{
	while (SD_MMC_OK != sd_mmc_check(0)) {
		/* Wait card ready. */
	}
	if (sd_mmc_get_type(0) & (CARD_TYPE_SD | CARD_TYPE_MMC)) {
		/* Read card block 0 */
		sd_mmc_init_read_blocks(0, 0, 1);
		sd_mmc_start_read_blocks(sd_mmc_block, 1);
		sd_mmc_wait_end_of_read_blocks(false);
	}
#if (CONF_SDIO_SUPPORT == 1)
	if (sd_mmc_get_type(0) & CARD_TYPE_SDIO) {
		/* Read 22 bytes from SDIO Function 0 (CIA) */
		sdio_read_extended(0, 0, 0, 1, sd_mmc_block, 22);
	}
#endif
}

void sd_mmc_stack_init(void)
{
	sd_mmc_init();
	sd_mmc_check(0);
	disk_initialize(0);
	//sd_mmc_init(&IO_BUS, SDMMC_cd, SDMMC_wp);
}
