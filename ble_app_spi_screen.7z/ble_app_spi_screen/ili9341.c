/**
 * \file
 *
 * \brief ILI9341 display controller component driver
 *
 * Copyright (c) 2012-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include "conf_ili9341.h"
#include "ili9341.h"
#include "ili9341_regs.h"
#include <stdbool.h>
#include "fonts.h"
#include <string.h>
//#include "gpio/pio.h"
//#include <sysclk.h>
//#include <ioport.h>
//#include <delay.h>

extern void msleep(uint32_t delay);
extern void pio_set(uint16_t pin);
extern void pio_clear(uint16_t pin);
extern void spi_write(uint8_t param1,uint8_t param2);
extern uint8_t spi_read(uint8_t param1);
uint8_t font_r=0;
uint8_t font_g=0;
uint8_t font_b=0;

/**
 * \internal
 * \brief Helper function to select the CS of the controller on the bus
 */
static void ili9341_select_chip(void)
{
	//ioport_set_pin_level(CONF_ILI9341_CS_PIN, false);
	pio_clear(30);
	
}

/**
 * \internal
 * \brief Helper function to de-select the CS of the controller on the bus
 */
static void ili9341_deselect_chip(void)
{
	//ioport_set_pin_level(CONF_ILI9341_CS_PIN, true);
	pio_set(30);
}

/**
 * \internal
 * \brief Helper function to select command byte transmission mode
 */
static void ili9341_select_command_mode(void)
{
	//ioport_set_pin_level(CONF_ILI9341_DC_PIN, false);
	pio_clear(2);
}

/**
 * \internal
 * \brief Helper function to select data byte transmission mode
 */
static void ili9341_select_data_mode(void)
{
	//ioport_set_pin_level(CONF_ILI9341_DC_PIN, true);
	pio_set(2);
}

/**
 * \internal
 * \brief Helper function to wait for the last send operation to complete
 */
static void ili9341_wait_for_send_done(void)
{
#if defined(CONF_ILI9341_USART_SPI)
#  if XMEGA
	while (!usart_tx_is_complete(CONF_ILI9341_USART_SPI)) {
		/* Do nothing */
	}
	usart_clear_tx_complete(CONF_ILI9341_USART_SPI);
#  else
	/* Wait for TX to complete */
	while (!usart_spi_is_tx_empty(CONF_ILI9341_USART_SPI)) {
		/* Do nothing */
	}
#  endif
#elif defined(CONF_ILI9341_SPI)
	/* Wait for TX to complete */
	//while (!spi_is_tx_finished(SPI1)) {
		/* Do nothing */
	//}
#endif
}

/**
 * \internal
 * \brief Helper function to send a byte over an arbitrary interface
 *
 * This function is used to hide what interface is used by the component
 * driver, e.g.  the component driver does not need to know if USART in SPI
 * mode is used or the native SPI module.
 *
 * \param data The byte to be transfered
 */
static void ili9341_send_byte(uint8_t data)
{
#if defined(CONF_ILI9341_USART_SPI)
#  if XMEGA
	while (!usart_data_register_is_empty(CONF_ILI9341_USART_SPI)) {
		/* Do nothing */
	}

	irqflags_t flags = cpu_irq_save();
	usart_clear_tx_complete(CONF_ILI9341_USART_SPI);
	usart_put(CONF_ILI9341_USART_SPI, data);
	cpu_irq_restore(flags);
#  else
	usart_spi_write_single(CONF_ILI9341_USART_SPI, data);
#  endif
#elif defined(CONF_ILI9341_SPI)
	/* Wait for any previously running send data */
	ili9341_wait_for_send_done();

	spi_write(NULL, data);
        //spi_read(NULL);
#endif
}

/**
 * \internal
 * \brief Helper function to read a byte from an arbitrary interface
 *
 * This function is used to hide what interface is used by the component
 * driver, e.g.  the component driver does not need to know if USART in SPI
 * mode is used or the native SPI module.
 *
 * \retval uint8_t Byte of data read from the display controller
 */
 static uint8_t ili9341_read_byte(void)
{
	uint8_t data;

#if defined(CONF_ILI9341_USART_SPI)
#  if XMEGA
	/* Workaround for clearing the RXCIF for XMEGA */
	usart_rx_enable(CONF_ILI9341_USART_SPI);

	usart_put(CONF_ILI9341_USART_SPI, 0xFF);
	while (!usart_rx_is_complete(CONF_ILI9341_USART_SPI)) {
		/* Do nothing */
	}
	data = usart_get(CONF_ILI9341_USART_SPI);

	/* Workaround for clearing the RXCIF for XMEGA */
	usart_rx_disable(CONF_ILI9341_USART_SPI);
#  else
	usart_spi_read_single(CONF_ILI9341_USART_SPI, &data);
#  endif
#elif defined(CONF_ILI9341_SPI)
	//spi_write(CONF_ILI9341_SPI, 0xFF);

	//ili9341_wait_for_send_done();

	/* Wait for RX to complete */
//	while (!spi_is_rx_full(CONF_ILI9341_SPI)) {
		/* Do nothing */
//	}

	data = spi_read(CONF_ILI9341_SPI);
#endif

	return data;
}

/**
 * \internal
 * \brief Sends a command to the controller, and prepares for parameter transfer
 *
 * Helper function to use for sending a command to the controller.
 *
 * \note After the command is sent, the display remains selected.
 *
 * \param command The command to send
 */
static void ili9341_send_command(uint8_t command)
{
	ili9341_select_command_mode();
	ili9341_select_chip();
	ili9341_send_byte(command);
	ili9341_wait_for_send_done();
	ili9341_select_data_mode();
}

static ili9341_coord_t limit_start_x, limit_start_y;
static ili9341_coord_t limit_end_x, limit_end_y;

/**
 * \internal
 * \brief Helper function to send the drawing limits (boundaries) to the display
 *
 * This function is used to send the currently set upper-left and lower-right
 * drawing limits to the display, as set through the various limit functions.
 *
 * \param send_end_limits  True to also send the lower-right drawing limits
 */
static void ili9341_send_draw_limits(const bool send_end_limits)
{
	ili9341_send_command(ILI9341_CMD_COLUMN_ADDRESS_SET);
	ili9341_send_byte(limit_start_x >> 8);
	ili9341_send_byte(limit_start_x & 0xFF);
	if (send_end_limits) {
		ili9341_send_byte(limit_end_x >> 8);
		ili9341_send_byte(limit_end_x & 0xFF);
	}
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_PAGE_ADDRESS_SET);
	ili9341_send_byte(limit_start_y >> 8);
	ili9341_send_byte(limit_start_y & 0xFF);
	if (send_end_limits) {
		ili9341_send_byte(limit_end_y >> 8);
		ili9341_send_byte(limit_end_y & 0xFF);
	}
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();
}

/**
 * \brief Set the display top left drawing limit
 *
 * Use this function to set the top left limit of the drawing limit box.
 *
 * \param x The x coordinate of the top left corner
 * \param y The y coordinate of the top left corner
 */
void ili9341_set_top_left_limit(ili9341_coord_t x, ili9341_coord_t y)
{
	limit_start_x = x;
	limit_start_y = y;

	ili9341_send_draw_limits(false);
}

/**
 * \brief Set the display bottom right drawing limit
 *
 * Use this function to set the bottom right corner of the drawing limit box.
 *
 * \param x The x coordinate of the bottom right corner
 * \param y The y coordinate of the bottom right corner
 */
void ili9341_set_bottom_right_limit(ili9341_coord_t x, ili9341_coord_t y)
{
	limit_end_x = x;
	limit_end_y = y;

	ili9341_send_draw_limits(true);
}

/**
 * \brief Set the full display drawing limits
 *
 * Use this function to set the full drawing limit box.
 *
 * \param start_x The x coordinate of the top left corner
 * \param start_y The y coordinate of the top left corner
 * \param end_x The x coordinate of the bottom right corner
 * \param end_y The y coordinate of the bottom right corner
 */
void ili9341_set_limits(ili9341_coord_t start_x, ili9341_coord_t start_y,
		ili9341_coord_t end_x, ili9341_coord_t end_y)
{
	limit_start_x = start_x;
	limit_start_y = start_y;
	limit_end_x = end_x;
	limit_end_y = end_y;

	ili9341_send_draw_limits(true);
}

/**
 * \brief Read a single color from the graphical memory
 *
 * Use this function to read a color from the graphical memory of the
 * controller.
 *
 * Limits have to be set prior to calling this function, e.g.:
 * \code
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	...
\endcode
 *
 * \retval ili9341_color_t The read color pixel
 */
ili9341_color_t ili9341_read_gram(void)
{
	uint8_t red, green, blue;

	ili9341_send_command(ILI9341_CMD_MEMORY_READ);

	/* No interesting data in the first byte, hence read and discard */
	red = ili9341_read_byte();

	red = ili9341_read_byte();
	green = ili9341_read_byte();
	blue = ili9341_read_byte();

	ili9341_deselect_chip();

	return ILI9341_COLOR(red, green, blue);
}

/**
 * \brief Write the graphical memory with a single color pixel
 *
 * Use this function to write a single color pixel to the controller memory.
 *
 * Limits have to be set prior to calling this function, e.g.:
 * \code
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	...
\endcode
 *
 * \param color The color pixel to write to the screen
 */
void ili9341_write_gram(ili9341_color_t color)
{
	/* Only 16-bit color supported */
	//Assert(sizeof(color) == 2);

	ili9341_send_command(ILI9341_CMD_MEMORY_WRITE);
	ili9341_send_byte(color);
	ili9341_send_byte(color >> 8);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();
}

/**
 * \brief Copy pixels from SRAM to the screen
 *
 * Used to copy a large quantitative of data to the screen in one go.
 *
 * Limits have to be set prior to calling this function, e.g.:
 * \code
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	...
\endcode
 *
 * \param pixels Pointer to the pixel data
 * \param count Number of pixels to copy to the screen
 */
void ili9341_copy_pixels_to_screen(const ili9341_color_t *pixels, uint32_t count)
{
	const ili9341_color_t *pixel = pixels;

	/* Sanity check to make sure that the pixel count is not zero */
	//Assert(count > 0);

	ili9341_send_command(ILI9341_CMD_MEMORY_WRITE);

#if defined(ILI9341_DMA_ENABLED)
	ili9341_color_t chunk_buf[ILI9341_DMA_CHUNK_SIZE];
	uint32_t chunk_len;

#  if SAM
	Pdc *SPI_DMA = spi_get_pdc_base(CONF_ILI9341_SPI);
	pdc_packet_t spi_pdc_data;

	pdc_enable_transfer(SPI_DMA, PERIPH_PTCR_TXTEN);
	spi_pdc_data.ul_addr = (uint32_t)chunk_buf;
#  elif UC3
	pdca_set_transfer_size(CONF_ILI9341_PDCA_CHANNEL,
			PDCA_TRANSFER_SIZE_BYTE);
	pdca_set_peripheral_select(CONF_ILI9341_PDCA_CHANNEL,
			CONF_ILI9341_PDCA_PID);
#  endif

	while (count)
	{
		/* We need to copy out the data to send in chunks into RAM, as the PDC
		 * does not allow FLASH->Peripheral transfers */
		chunk_len = min(ILI9341_DMA_CHUNK_SIZE, count);

		/* Wait for pending transfer to complete */
		ili9341_wait_for_send_done();

		for (uint32_t i = 0; i < chunk_len; i++) {
			chunk_buf[i] = le16_to_cpu(pixel[i]);
		}

#  if SAM
		spi_pdc_data.ul_size = (uint32_t)sizeof(ili9341_color_t) * chunk_len;
		pdc_tx_init(SPI_DMA, NULL, &spi_pdc_data);
#  elif UC3
		pdca_reload_channel(CONF_ILI9341_PDCA_CHANNEL, chunk_buf,
				(uint32_t)sizeof(ili9341_color_t) * chunk_len);
		pdca_enable(CONF_ILI9341_PDCA_CHANNEL);
#  endif

		pixel += chunk_len;
		count -= chunk_len;
	}

	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

#  if SAM
	pdc_disable_transfer(SPI_DMA, PERIPH_PTCR_TXTEN);
#  elif UC3
	pdca_disable(CONF_ILI9341_PDCA_CHANNEL);
#  endif
#else
	while (count--) {
		ili9341_send_byte(*pixel);
		ili9341_send_byte(*pixel >> 8);

		pixel++;
	}

	ili9341_wait_for_send_done();
	ili9341_deselect_chip();
#endif
}


/**
 * \brief Set a given number of pixels to the same color
 *
 * Use this function to write a certain number of pixels to the same color
 * within a set limit.
 *
 * Limits have to be set prior to calling this function, e.g.:
 * \code
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	...
\endcode
 *
 * \param color The color to write to the display
 * \param count The number of pixels to write with this color
 */
void ili9341_duplicate_pixel(const ili9341_color_t color, uint32_t count)
{
	/* Sanity check to make sure that the pixel count is not zero */
	//Assert(count > 0);

	ili9341_send_command(ILI9341_CMD_MEMORY_WRITE);

#if defined(ILI9341_DMA_ENABLED)
	ili9341_color_t chunk_buf[ILI9341_DMA_CHUNK_SIZE];
	uint32_t chunk_len;

#  if SAM
	Pdc *SPI_DMA = spi_get_pdc_base(CONF_ILI9341_SPI);
	pdc_packet_t spi_pdc_data;

	pdc_enable_transfer(SPI_DMA, PERIPH_PTCR_TXTEN);
	spi_pdc_data.ul_addr = (uint32_t)chunk_buf;
#  elif UC3
	pdca_set_transfer_size(CONF_ILI9341_PDCA_CHANNEL,
			PDCA_TRANSFER_SIZE_BYTE);
	pdca_set_peripheral_select(CONF_ILI9341_PDCA_CHANNEL,
			CONF_ILI9341_PDCA_PID);
#  endif

	for (uint32_t i = 0; i < ILI9341_DMA_CHUNK_SIZE; i++) {
		chunk_buf[i] = le16_to_cpu(color);
	}

	while (count)
	{
		chunk_len = min(ILI9341_DMA_CHUNK_SIZE, count);

		ili9341_wait_for_send_done();

#  if SAM
		spi_pdc_data.ul_size = (uint32_t)sizeof(ili9341_color_t) * chunk_len;
		pdc_tx_init(SPI_DMA, NULL, &spi_pdc_data);
#  elif UC3
		pdca_reload_channel(CONF_ILI9341_PDCA_CHANNEL, chunk_buf,
				(uint32_t)sizeof(ili9341_color_t) * chunk_len);
		pdca_enable(CONF_ILI9341_PDCA_CHANNEL);
#  endif

		count -= chunk_len;
	}

	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

#  if SAM
	pdc_disable_transfer(SPI_DMA, PERIPH_PTCR_TXTEN);
#  elif UC3
	pdca_disable(CONF_ILI9341_PDCA_CHANNEL);
#  endif
#else
	while (count--) {
		ili9341_send_byte(color);
		ili9341_send_byte(color >> 8);
	}

	ili9341_wait_for_send_done();
	ili9341_deselect_chip();
#endif
}

/**
 * \brief Copy pixels from the screen to a pixel buffer
 *
 * Use this function to copy pixels from the display to an internal SRAM buffer.
 *
 * Limits have to be set prior to calling this function, e.g.:
 * \code
	ili9341_set_top_left_limit(0, 0);
	ili9341_set_bottom_right_limit(320, 240);
	...
\endcode
 *
 * \param pixels Pointer to the pixel buffer to read to
 * \param count Number of pixels to read
 */
void ili9341_copy_pixels_from_screen(ili9341_color_t *pixels, uint32_t count)
{
	uint8_t red, green, blue;

	/* Sanity check to make sure that the pixel count is not zero */
	//Assert(count > 0);

	ili9341_send_command(ILI9341_CMD_MEMORY_READ);

	/* No interesting data in the first byte, hence read and discard */
	red = ili9341_read_byte();

	while (count--) {
		red = ili9341_read_byte();
		green = ili9341_read_byte();
		blue = ili9341_read_byte();

		*pixels = ILI9341_COLOR(red, green, blue);
		pixels++;
	}

	ili9341_deselect_chip();
}

/**
 * \internal
 * \brief Initialize the hardware interface to the controller
 *
 * This will initialize the module used for communication with the controller.
 * Currently supported interfaces by this component driver are the SPI
 * interface through either the SPI module in master mode or the USART in
 * Master SPI mode.  Configuration must be done in the associated
 * conf_ili9341.h file.
 */
void ili9341_backlight_on(void)
{
	//ioport_set_pin_level(CONF_ILI9341_BACKLIGHT_PIN, true);
	//pio_set(&LCD_BL);
}

/**
 * \brief Function to turn off the display back light
 *
 * Use this function to simply set the pin controlling the back light low to
 * turn off the back light.
 */
void ili9341_backlight_off(void)
{
	//ioport_set_pin_level(CONF_ILI9341_BACKLIGHT_PIN, false);
	//pio_clear(&LCD_BL);
}

static void ili9341_interface_init(void)
{
#if defined(CONF_ILI9341_USART_SPI) || defined(CONF_ILI9341_SPI)

  // FLAGS SECTION FOR SPI CONFIG
  
  
#endif


}

/**
 * \internal
 * \brief Initialize all the display registers
 *
 * This function will set up all the internal registers according the the
 * manufacturer's description.
 */
static void ili9341_controller_init_registers(void)
{
	ili9341_send_command(ILI9341_CMD_POWER_CONTROL_A);
	ili9341_send_byte(0x39);
	ili9341_send_byte(0x2C);
	ili9341_send_byte(0x00);
	ili9341_send_byte(0x34);
	ili9341_send_byte(0x02);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_POWER_CONTROL_B);
	ili9341_send_byte(0x00);
	ili9341_send_byte(0xAA);
	ili9341_send_byte(0XB0);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_PUMP_RATIO_CONTROL);
	ili9341_send_byte(0x30);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_POWER_CONTROL_1);
	ili9341_send_byte(0x25);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_POWER_CONTROL_2);
	ili9341_send_byte(0x11);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_VCOM_CONTROL_1);
	ili9341_send_byte(0x5C);
	ili9341_send_byte(0x4C);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_VCOM_CONTROL_2);
	ili9341_send_byte(0x94);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_DRIVER_TIMING_CONTROL_A);
	ili9341_send_byte(0x85);
	ili9341_send_byte(0x01);
	ili9341_send_byte(0x78);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_DRIVER_TIMING_CONTROL_B);
	ili9341_send_byte(0x00);
	ili9341_send_byte(0x00);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_send_command(ILI9341_CMD_COLMOD_PIXEL_FORMAT_SET);
	ili9341_send_byte(0x05);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();

	ili9341_set_orientation(0);
	ili9341_set_limits(0, 0, ILI9341_DEFAULT_WIDTH,
			ILI9341_DEFAULT_HEIGHT);
}

/**
 * \internal
 * \brief Send display commands to exit standby mode
 *
 * This function is used to exit the display standby mode, which is the default
 * mode after a reset signal to the display.
 */
static void ili9341_exit_standby(void)
{
	ili9341_send_command(ILI9341_CMD_SLEEP_OUT);
	ili9341_deselect_chip();
	msleep(150);
	ili9341_send_command(ILI9341_CMD_DISPLAY_ON);
	ili9341_deselect_chip();
}

/**
 * \internal
 * \brief Reset the display using the digital control interface
 *
 * Controls the reset pin of the display controller to reset the display.
 */
static void ili9341_reset_display(void)
{
	//ioport_set_pin_level(CONF_ILI9341_RESET_PIN, true);
//	pio_set_output(PIOC, PIO_PC21, HIGH, DISABLE, ENABLE);
	msleep(10);
	//ioport_set_pin_level(CONF_ILI9341_RESET_PIN, false);
	//pio_set_output(PIOC, PIO_PC21, LOW, DISABLE, ENABLE);
	msleep(10);
	//ioport_set_pin_level(CONF_ILI9341_RESET_PIN, true);
	//pio_set_output(PIOC, PIO_PC21, HIGH, DISABLE, ENABLE);
	msleep(150);
}

/**
 * \brief Initialize the controller
 *
 * Used to initialize the ILI9341 display controller by setting up the hardware
 * interface, and setting up the controller according to the manufacturer's
 * description. It also set up the screen orientation to the default state
 * (portrait).
 */
void ili9341_init(void)
{
	/* Initialize the communication interface */
	ili9341_interface_init();

	/* Reset the display */
	ili9341_reset_display();

	/* Send commands to exit standby mode */
	ili9341_exit_standby();

	/* Write all the controller registers with correct values */
	ili9341_controller_init_registers();
}

/**
 * \brief Sets the orientation of the display data
 *
 * Configures the display for a given orientation, including mirroring and/or
 * screen rotation.
 *
 * \param flags Orientation flags to use, see \ref ILI9341_FLIP_X, \ref ILI9341_FLIP_Y
 *        and \ref ILI9341_SWITCH_XY.
 */
void ili9341_set_orientation(uint8_t flags)
{
	uint8_t madctl = 0x48;

	/* Pretend the display is in landscape mode by default to match other display drivers */
	flags ^= ILI9341_SWITCH_XY | ILI9341_FLIP_X;

	if (flags & ILI9341_FLIP_X) {
		madctl &= ~(1 << 6);
	}

	if (flags & ILI9341_FLIP_Y) {
		madctl |= 1 << 7;
	}

	if (flags & ILI9341_SWITCH_XY) {
		madctl |= 1 << 5;
	}

	ili9341_send_command(ILI9341_CMD_MEMORY_ACCESS_CONTROL);
	ili9341_send_byte(madctl);
	ili9341_wait_for_send_done();
	ili9341_deselect_chip();
}
void display_print_letter(uint16_t x_crd, uint16_t y_crd, char letter,uint8_t background_r,uint8_t background_g,uint8_t background_b,uint8_t To_scrbuf){

        uint16_t logo[10];
	uint8_t* L_tab;
	if(letter == 'A'){L_tab=L_A;}
	else if(letter == 'B'){L_tab=L_B;}
	else if(letter == 'C'){L_tab=L_C;}
	else if(letter == 'D'){L_tab=L_D;}
	else if(letter == 'E'){L_tab=L_E;}
	else if(letter == 'F'){L_tab=L_F;}
	else if(letter == 'G'){L_tab=L_G;}
	else if(letter == 'H'){L_tab=L_H;}
	else if(letter == 'I'){L_tab=L_I;}
	else if(letter == 'J'){L_tab=L_J;}
	else if(letter == 'K'){L_tab=L_K;}
	else if(letter == 'L'){L_tab=L_L;}
	else if(letter == 'M'){L_tab=L_M;}
	else if(letter == 'N'){L_tab=L_N;}
	else if(letter == 'O'){L_tab=L_O;}
	else if(letter == 'Q'){L_tab=L_Q;}
	else if(letter == 'U'){L_tab=L_U;}
	else if(letter == 'P'){L_tab=L_P;}
	else if(letter == 'R'){L_tab=L_R;}
	else if(letter == 'S'){L_tab=L_S;}
	else if(letter == 'T'){L_tab=L_T;}
	else if(letter == 'W'){L_tab=L_W;}
	else if(letter == 'Y'){L_tab=L_Y;}
	else if(letter == 'Z'){L_tab=L_Z;}
	else if(letter == 'X'){L_tab=L_X;}
	else if(letter == 'V'){L_tab=L_V;}
	
	else if(letter == 'a'){L_tab=L_a;}
	else if(letter == 'b'){L_tab=L_b;}
	else if(letter == 'c'){L_tab=L_c;}
	else if(letter == 'd'){L_tab=L_d;}
	else if(letter == 'e'){L_tab=L_e;}
	else if(letter == 'f'){L_tab=L_f;}
	else if(letter == 'g'){L_tab=L_g;}
	else if(letter == 'h'){L_tab=L_h;}
	else if(letter == 'i'){L_tab=L_i;}
	else if(letter == 'j'){L_tab=L_j;}
	else if(letter == 'k'){L_tab=L_k;}
	else if(letter == 'l'){L_tab=L_l;}
	else if(letter == 'm'){L_tab=L_m;}
	else if(letter == 'n'){L_tab=L_n;}
	else if(letter == 'o'){L_tab=L_o;}
	else if(letter == 'q'){L_tab=L_q;}
	else if(letter == 'u'){L_tab=L_u;}
	else if(letter == 'p'){L_tab=L_p;}
	else if(letter == 'r'){L_tab=L_r;}
	else if(letter == 's'){L_tab=L_s;}
	else if(letter == 't'){L_tab=L_t;}
	else if(letter == 'w'){L_tab=L_w;}
	else if(letter == 'y'){L_tab=L_y;}
	else if(letter == 'z'){L_tab=L_z;}
	else if(letter == 'x'){L_tab=L_x;}
	else if(letter == 'v'){L_tab=L_v;}

	else if(letter == '0'){L_tab=L_0;}
	else if(letter == '1'){L_tab=L_1;}
	else if(letter == '2'){L_tab=L_2;}
	else if(letter == '3'){L_tab=L_3;}
	else if(letter == '4'){L_tab=L_4;}
	else if(letter == '5'){L_tab=L_5;}
	else if(letter == '6'){L_tab=L_6;}
	else if(letter == '7'){L_tab=L_7;}
	else if(letter == '8'){L_tab=L_8;}
	else if(letter == '9'){L_tab=L_9;}
        else if(letter == '.'){L_tab=L_DOT;}
        else if(letter == ','){L_tab=L_DOT;}
	
	else if(letter == ':'){L_tab=L_COL;}
	else if(letter == ';'){L_tab=L_SCOL;}
	else if(letter == '.'){L_tab=L_DOT;}
	else if(letter == ' '){L_tab=L_SP;}
	else if(letter == '_'){L_tab=L_LSP;}
	else if(letter == '-'){L_tab=L_MIN;}
	else if(letter == '+'){L_tab=L_PLS;}
	else if(letter == '>'){L_tab=L_RSLASH;}
	else if(letter == '<'){L_tab=L_LSLASH;}
	else if(letter == '\r'){L_tab=L_RTN;}
	else if(letter == '/'){L_tab=L_RSL;}
	else if(letter == '='){L_tab=L_EQUAL;}
	else if(letter == '^'){L_tab=L_STG;}
	else if(letter == 9){L_tab=L_RTN;}
    
	else {L_tab=L_SP;}
	for(int j=0;j<10;j++){
		ili9341_set_top_left_limit(x_crd-7, y_crd+j);
		ili9341_set_bottom_right_limit(x_crd , y_crd+j );
		for(int i=0;i<7;i++){

			if(L_tab[j]&(1<<(6-i))){
				
				logo[6-i] = ILI9341_COLOR(font_r, font_g, font_b);
			}
			else{
				logo[6-i] = ILI9341_COLOR(background_r, background_g, background_b);
			}
		}
		ili9341_copy_pixels_to_screen(logo,7);
		if(To_scrbuf!=0){
		for (int si=0;si<7;si++)
		{
			//Screen_pix[x_crd-7+si+(y_crd+j)*320] = logo[si];
		}
		}
	}

}

void display_string(uint16_t x_crd, uint16_t y_crd,const char* p_string,uint8_t background_r,uint8_t background_g,uint8_t background_b,uint8_t To_scrbuf){
	
	for(int i2=0;i2<strlen(p_string);i2++){display_print_letter(x_crd-7*(i2),y_crd,p_string[i2],background_r,background_g,background_b,To_scrbuf);}
}
